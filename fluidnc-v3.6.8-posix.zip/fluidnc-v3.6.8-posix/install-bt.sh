#!/bin/sh

BuildType=bt

if ! . ./tools.sh; then exit 1; fi

install

deactivate
